website
=======

###PilotSuits

1. Migrate to JekyllRB
2. Add a spotify follow icon

                        <iframe src="https://embed.spotify.com/follow/1/?uri=spotify:artist:7xDEsNpkGIBp0UnHTqnfr6&size=detail&theme=light" width="300" height="56" scrolling="no" frameborder="0" style="border:none; overflow:hidden;" allowtransparency="true"></iframe>
    
###Jaja Jr. jr. site

1. jrjr site, make about section like original ps landing page, w/ scroll
